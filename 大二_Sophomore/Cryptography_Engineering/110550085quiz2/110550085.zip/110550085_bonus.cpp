#include <iostream>
using namespace std;

int main(){
    cout<<"WHY DID YOU LOOK IF I CALLED THE WRONG NUMBER ANSWER THE PHONE\n";
}